/* Kalimat service worker: cache the app shell and static Firebase modules only. */
const CACHE_NAME = "kalimat-shell-v2";
const SHELL_FILES = ["./index.htm", "./manifest.json", "./favicon.svg"];
const STATIC_HOSTS = new Set(["www.gstatic.com", "cdnjs.cloudflare.com"]);

self.addEventListener("install", (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    await cache.addAll(SHELL_FILES);
    await self.skipWaiting();
  })());
});

self.addEventListener("activate", (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((key) => key.startsWith("kalimat-") && key !== CACHE_NAME).map((key) => caches.delete(key)));
    await self.clients.claim();
  })());
});

self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  const sameOrigin = url.origin === self.location.origin;
  const cacheableStatic = STATIC_HOSTS.has(url.hostname) &&
    (url.hostname === "www.gstatic.com" ? url.pathname.startsWith("/firebasejs/") : url.pathname.includes("font-awesome"));
  if (!sameOrigin && !cacheableStatic) return;

  event.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);
    const cached = await cache.match(request);
    if (cached) return cached;
    try {
      const response = await fetch(request);
      if (response && response.ok && (sameOrigin || cacheableStatic)) {
        await cache.put(request, response.clone());
      }
      return response;
    } catch (error) {
      if (request.mode === "navigate") {
        return (await cache.match("./index.htm")) || Response.error();
      }
      return new Response("", { status: 503, statusText: "Offline" });
    }
  })());
});
